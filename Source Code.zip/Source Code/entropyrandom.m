function result = entropy(imageori)
%Calculate the entropy of random image.
Image1 = imageori;

image_minGray = min(min(Image1));
image_maxGray = max(max(Image1));
image_distance = image_maxGray-image_minGray;
Image1 = (Image1-image_minGray)/image_distance; 
min_Gray = 1;
max_Gray = 32;
Image1 = max_Gray*Image1 +min_Gray; 
Image1 = fix(Image1);

img = Image1;
[M,N]=size(img);
imax=ceil(max(max(img)));
temp=zeros(1,imax);

for m=1:M;
    for n=1:N;
        i=fix(img(m,n));
        temp(i)=temp(i)+1;
    end
end

temp=temp./(M*N);

resul=0;
for i=1:length(temp)
    if temp(i)==0;
        resul=resul;
    else
        resul=resul-temp(i)*log2(temp(i));
    end
end
result=resul;

end

