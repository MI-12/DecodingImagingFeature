
##The distribution of the values of those important texture features on the random image, lung cancer image is calculated in this script.

library(ggplot2)
library(RColorBrewer)

workbook1<-"load the 'resultofrealimage' and the 'resultofrandom' data which have been obtained by the 'Improtant_features_calculation.m'" 
Sta1 = read_excel(workbook1,1)
FeatureValues<-Sta1
FeatureValues1 = data.frame(Group = FeatureValues$Class ,Value = FeatureValues$Contrast4 )
FeatureValues1$Group = factor(FeatureValues1$Group,levels = c(1,2,3))

P1 <-ggplot(FeatureValues1,aes(x=Group,y=Value,fill=Group))+ 
  stat_boxplot(geom = "errorbar",width=0.15,aes(color="black"))+ 
  geom_boxplot(size=0.9,fill="white",outlier.fill="white",outlier.color="white")+ 
  geom_jitter(aes(fill=Group),width =0.2,shape = 21,size=2.0)+ 
  scale_fill_manual(values = c("#FF0000", "#00FF00","#0000FF"))+  
  scale_color_manual(values=c("black","black","black"))+
  ggtitle("")+ 
  theme_bw()+ 
  theme(legend.position="none", 
        axis.text.x=element_text(colour="black",family="Times",size=14), 
        axis.text.y=element_text(family="Times",size=14,face="plain"), 
        axis.title.y=element_text(family="Times",size = 14,face="plain"),
        axis.title.x=element_text(family="Times",size = 14,face="plain"), 
        plot.title = element_text(family="Times",size=15,face="bold",hjust = 0.5), 
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())+
  ylab("Contrast")+xlab("") 
P1
tiff(file = "save your boxplot",width =2400,height = 1000,units = "px",res =300)
print(P1)
dev.off()

x1<-FeatureValues1[which(FeatureValues1[,"Group"]=="1"),"Value"] ##1.500 patient images with low entropy
x2<-FeatureValues1[which(FeatureValues1[,"Group"]=="2"),"Value"] ##2.500 patient images with high entropy
x3<-FeatureValues1[which(FeatureValues1[,"Group"]=="3"),"Value"] ##3.500 random images.
var.test(x1,x2)
var.test(x1,x3)
var.test(x2,x3)
x<-aov(Value~Group,data=FeatureValues1) 
summary(x)