function [result,count] = entropy(imageori,imageseg)
%Calculate the entropy of cancer images.
index=(imageseg==4096);
count1 = length(find(imageseg==4096));
imageori(~index)=4096;

Image1 = double(imageori);


image_minGray = min(min(Image1(index)));
image_maxGray = max(max(Image1(index)));
image_distance = image_maxGray-image_minGray;
Image1(index) = (Image1(index)-image_minGray)/image_distance; 
min_Gray = 1;
max_Gray = 32;
Image1(index) = max_Gray*Image1(index) +min_Gray; 
Image1 = fix(Image1);

imax=ceil(max(max((Image1(index)))));
temp=zeros(1,imax);
[M,N]=size(Image1);

for m=1:M;
    for n=1:N;
        if(Image1(m,n)~=4096)
            i=fix(Image1(m,n));
            temp(i)=temp(i)+1;
        end
    end
end

temp=temp./count1;

resul=0;
for i=1:length(temp)
    if temp(i)==0;
        resul=resul;
    else
        resul=resul-temp(i)*log2(temp(i));
    end
end
result=resul;
count=count1;
end

