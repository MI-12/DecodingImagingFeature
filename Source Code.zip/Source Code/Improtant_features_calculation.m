
%%entropy, standard deviation, count of pixels, and the correlation, contrast, energy, and homogeneity features calculated in four directions. 

clc;
clear;
close all;

%% random images
resultofrandom = zeros(500,20);
for i =1:500
    RandomImage1 = ceil(rand(32,32)*32); %%random image initialization.
    resultofrandom(i,2) = entropyrandom(RandomImage1); %% entropy calculation of the random images.
    resultofrandom(i,1) = i;
    resultofrandom(i,3) = 1024;
    RandomImage1 = fix(RandomImage1);
    %%graycomatrix was used to obtain the feature of standard deviation, correlation, contrast, energy, and homogeneity features in four directions.
    [GLCMS,SI] = graycomatrix(RandomImage1,'GrayLimits',[1,32],'NumLevels',32,'Offset',[0 1;-1 1;-1 0;-1 -1]); 

    status = graycoprops(GLCMS);
    resultofrandom(i,4:7) = deal(status.Contrast);
    resultofrandom(i,8:11) = deal(status.Correlation);
    resultofrandom(i,12:15) = deal(status.Energy);
    resultofrandom(i,16:19) = deal(status.Homogeneity);
    resultofrandom(i,20)=std(RandomImage1(1:end),0);
end

%%CT images of the 1000 lung cancer patients.
resultofrealimage = zeros(1025,20);
for i = 1:1000
    DicomReadSegtrace = ['Path of the data set in your personal computer'];
    PatientFile=dir(DicomReadSegtrace);
    if(length(PatientFile) > 2)
        DicomReadSegtrace = ['Path of the data set in your personal computer + the segmented mask images'];
        PatientFile=dir(DicomReadSegtrace);
        DicomReadSeg = dicomread(DicomReadSegtrace);

        DicomReadOriTrace = ['Path of the data set in your personal computer + the original images'];
        PatientFile=dir(DicomReadOriTrace);
        DicomReadOri = dicomread(DicomReadOriTrace);
        resultofrealimage(i,1) = i;
        [resultofrealimage(i,2),resultofrealimage(i,3)] = entropy(DicomReadOri,DicomReadSeg);%%entropy of the lung cancer images.

        DicomReadOri = double(DicomReadOri);
        DicomReadOri(DicomReadSeg~=4096)=-1000;

        image_minGray = min(min(DicomReadOri(DicomReadOri~=-1000)));
        image_maxGray = max(max(DicomReadOri(DicomReadOri~=-1000)));
        image_distance = image_maxGray-image_minGray;
        DicomReadOri(DicomReadOri~=-1000) = (DicomReadOri(DicomReadOri~=-1000)-image_minGray)/image_distance; 
        min_Gray = 1;
        max_Gray = 32;
        DicomReadOri(DicomReadOri~=-1000) = max_Gray*DicomReadOri(DicomReadOri~=-1000) +min_Gray; 
        DicomReadOri = fix(DicomReadOri);
        %%graycomatrix was used to obtain the feature of standard deviation, correlation, contrast, energy, and homogeneity features in four directions.
        [GLCMS,SI] = graycomatrix(DicomReadOri,'GrayLimits',[1,32],'NumLevels',32,'Offset',[0 1;-1 1;-1 0;-1 -1]); 
        GLCMS(1,1)=0;
        status = graycoprops(GLCMS);
        resultofrealimage(i,4:7) = deal(status.Contrast);
        resultofrealimage(i,8:11) = deal(status.Correlation);
        resultofrealimage(i,12:15) = deal(status.Energy);
        resultofrealimage(i,16:19) = deal(status.Homogeneity);
        resultofrealimage(i,20)=std(DicomReadOri(DicomReadOri~=-1000),0);
    end
end
